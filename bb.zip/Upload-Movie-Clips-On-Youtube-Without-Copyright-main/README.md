# Upload-Movie-Clips-On-Youtube-Without-Copyright
 Use This FREE PYTHON BOT to Upload Movie Clips On Youtube Without Copyright
# How to Run This BOT:
 1. Install The Necessary Libraries: pip install -r requirements.txt<br>
 2. Add the link of your youtube clips in list_scenes.json file<br>
 3. Add the audio clip, & the music background in the audio folder<br>
 4. Run This BOT by typing this cmd: python movie.py<br>
 5. Watch this full tutorial on how to use this bot step by step<br>
    >https://youtu.be/AGD-alltz6g
